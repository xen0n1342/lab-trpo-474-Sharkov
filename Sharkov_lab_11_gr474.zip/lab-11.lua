
function run()

	local a = 2
	local b = 4
	local c = 1

	local x1,x2 = solve_eq(a,b,c)

	print(x1,x2)

end
