lgi = require'lgi'
gtk = lgi.Gtk
gtk.init()
bld = gtk.Builder()
bld:add_from_file('lab-02.glade')
ui = bld.objects
ui.wnd.title = 'lab-02'
ui.wnd:show_all()


function ui.btn_add:on_clicked()
  a = tonumber(ui.txt_first.text)
  b = tonumber(ui.txt_second.text)
  ui.res_label.label = a + b
end

function ui.btn_sub:on_clicked(...)
  a = tonumber(ui.txt_first.text)
  b = tonumber(ui.txt_second.text)
  ui.res_label.label = a - b
end

function ui.btn_mul:on_clicked(...)
  a = tonumber(ui.txt_first.text)
  b = tonumber(ui.txt_second.text)
  ui.res_label.label = a * b
end

function ui.btn_div:on_clicked(...)
  a = tonumber(ui.txt_first.text)
  b = tonumber(ui.txt_second.text)
  ui.res_label.label = a / b
end



ui.wnd.on_destroy = gtk.main_quit
gtk.main()
