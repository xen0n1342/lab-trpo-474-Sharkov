

rm -f lab-06.db
cat lab-06.sql | sqlite3 lab-06.db
